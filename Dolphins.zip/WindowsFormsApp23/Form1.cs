﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace WindowsFormsApp23
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
            SidePanel.Height = button1.Height;
            SidePanel.Top = button1.Top;




        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            SidePanel.Height = button1.Height;
            SidePanel.Top = button1.Top;
            label3.Visible = true;
            listView1.Visible = true;
            pictureBox2.Visible = true;

           

        }


        private void button2_Click(object sender, EventArgs e)
        {
            
            SidePanel.Height = button2.Height;
            SidePanel.Top = button2.Top;
            label3.Visible = false;
            listView1.Visible = false;
            pictureBox2.Visible = false;

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
           




        }

        private void webBrowser2_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {

        }

        private void pictureBox2_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            //마찬가지로 rect2와 b로 색을채운 원을 그린다.
            Rectangle rect2 = new Rectangle(0, 0, 5, 5);
            Brush b = new SolidBrush(Color.Black);
            g.FillEllipse(b, rect2);
        }
    }
}

