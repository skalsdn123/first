﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp23
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            webBrowser2.Visible = false;
            webBrowser1.ScriptErrorsSuppressed = true;
            webBrowser2.ScriptErrorsSuppressed = true;

            SidePanel.Height = button1.Height;
            SidePanel.Top = button1.Top;


        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            webBrowser1.Visible = true;
            webBrowser2.Visible = false;
            SidePanel.Height = button1.Height;
            SidePanel.Top = button1.Top;
            
        }


        private void button2_Click(object sender, EventArgs e)
        {
            webBrowser1.Visible = false;
            webBrowser2.Visible = true;
            SidePanel.Height = button2.Height;
            SidePanel.Top = button2.Top;


        }

    }
}
