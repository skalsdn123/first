﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;



namespace WindowsFormsApp23
{
    public partial  class Form1 : Form
    {

        float x, y;
        int k, t;
        Random rnd = new Random();

        MySqlConnection connection =   new MySqlConnection("Server=13.209.68.202;Database=iotdevices;Uid=mysqluser;Pwd=user1234;");

        
        public Form1()
        {
            InitializeComponent();
            InitializeTimer();     
        }

        private void InitializeTimer()
        {
            timer1.Interval = 600;
            timer1.Enabled = true;
            // Hook up timer's tick event handler.  
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
        }


        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            SidePanel.Height = button1.Height;
            SidePanel.Top = button1.Top;
            label3.Visible = true;
            listView1.Visible = true;
            pictureBox2.Visible = true;

            


        }


        private void button2_Click(object sender, EventArgs e)
        {
            
            SidePanel.Height = button2.Height;
            SidePanel.Top = button2.Top;
            label3.Visible = false;
            listView1.Visible = false;
            pictureBox2.Visible = false;

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

       
        private void pictureBox2_Paint(object sender, PaintEventArgs e)
        {
          /*  Graphics g = e.Graphics;

            
            Rectangle rect2 = new Rectangle(0, 0, 15, 15);
            Brush b = new SolidBrush(Color.Red);
            g.FillEllipse(b, rect2);*/

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            string insertQuery = "SELECT Helmet_Latitude,Helmet_Longitude FROM iotdevices.Helmet_Date order by Helmet_No desc limit 1";
            /* 추가한다    테이블 member_tb 테이블에  name 과 age 라는 항목의 값을 그값은 NameBox.Text 와  AgeBox.Text 에입력
             된 값이다*/

            connection.Open();


            try//예외 처리
            {
                MySqlCommand command = new MySqlCommand(insertQuery, connection);
                MySqlDataReader table = command.ExecuteReader();

                while (table.Read())
                {
                    x = Convert.ToSingle(table["Helmet_Latitude"].ToString());
                    y = Convert.ToSingle(table["Helmet_Longitude"].ToString());

                    k = Convert.ToInt32((x-36)*100);
                    t = Convert.ToInt32((y-127)*100);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


            connection.Close();

            /*Graphics g = this.pictureBox2.CreateGraphics();
            Pen p = new Pen(Color.Blue, 3);

            Rectangle rec = new Rectangle(k, t, 100, 20);
            g.DrawRectangle(p, rec);*/

            Graphics g = this.pictureBox2.CreateGraphics();


            Rectangle rect2 = new Rectangle(k, t, 15, 15);
            Brush b = new SolidBrush(Color.Red);
            g.FillEllipse(b, rect2); 
        }
    }
}

