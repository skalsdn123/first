﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
 
namespace WindowsFormsApp23
{
    public partial class Form2 : Form
    {


        public Form2()
        {
            InitializeComponent();

            


        }

      
       

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();


        }

        private void Form2_Load(object sender, EventArgs e)
        {
            textbox2.PasswordChar = '*';
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (textbox1.Text == "dolphins" && textbox2.Text == "a123")
            {
                MessageBox.Show("관리자님 안녕하세요");
                this.Hide();

                Form1 form1 = new Form1();
                form1.Show();
            }
            else
            {
                MessageBox.Show("아이디, 혹은 비밀번호를 확인해 주세요");
            }
            
        }

        }
    }

