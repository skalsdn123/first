﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
 
namespace WindowsFormsApp23
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();


        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
           
            
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\USER\Documents\Data5.mdf;Integrated Security=True;Connect Timeout=30");

                SqlDataAdapter sda = new SqlDataAdapter("Select Count(*) from USERINFO where USERNAME='"+ID_txt.Text+"' and PASSWORD='"+PW_txt.Text+"'",con);

            DataTable newTable = new DataTable();

            sda.Fill(newTable);

            if(newTable.Rows[0][0].ToString()=="1")
            { 
            this.Hide();

            Form1 form1 = new Form1();
            form1.Show();
            }
            else
            {
                MessageBox.Show("아이디와 비밀번호를 확인해주세요.");

            }

        }
    }
}
